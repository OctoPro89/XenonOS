#include "syscall.h"
#include <arch/x86_64/io.h>
#include <io/fd_table.h>
#include <io/fd.h>
#include <errno.h>
#include <process.h>
#include <elf/elf.h>
#include <windowing/window/window.h>
#include <windowing/window/internal.h>
#include <windowing/compositor/compositor.h>
#include <xlibc/string.h>
#include <tty/terminal.h>
#include <filesystem/vfs/vfs.h>
#include <memory/user.h>
#include <memory/heap.h>
#include <memory/paging.h>
#include <time/time.h>

// TODO: not sure if chunking is the best

u64 user_rsp_save;

#define SYSCALL_IO_BUFFER_SIZE 512

#define USER_PATH_MAX 256

static ssize_t directory_read(file_t* file, void* buffer, size_t size) {
    (void)file;
    (void)buffer;
    (void)size;
    return -EISDIR;
}

static ssize_t directory_write(file_t* file, const void* buffer, size_t size) {
    (void)file;
    (void)buffer;
    (void)size;
    return -EISDIR;
}

static ssize_t directory_seek(file_t* file, ssize_t offset, int whence) {
    (void)file;
    (void)offset;
    (void)whence;
    return -EISDIR;
}

static int directory_close(file_t* file) {
    if (!file) { return -EINVAL; }

    VFS_DIR* dir = (VFS_DIR*)file->private;

    file->private = NULL;

    if (dir) {
        vfs_closedir(dir);
    }

    return 0;
}

static const file_ops_t directory_file_ops = {
    .read  = directory_read,
    .write = directory_write,
    .seek  = directory_seek,
    .close = directory_close,
};

/**
 * @brief Copy a bounded, NULL-terminated path from userspace.
 * @returns 0 on success or a negative errno value
 */
static int copy_user_path(char out[USER_PATH_MAX], const char* user_path) {
    if (!user_path) {
        return -EFAULT;
    }

    for (size_t i = 0; i < USER_PATH_MAX; ++i) {
        if (copy_from_user(&out[i], user_path + i, 1) < 0) {
            return -EFAULT;
        }

        if (out[i] == '\0') {
            return 0;
        }
    }

    out[USER_PATH_MAX - 1] = '\0';
    return -ENAMETOOLONG;
}

ssize_t sys_read(fd_t fd, void* user_buffer, size_t size) {
    u8 buffer[SYSCALL_IO_BUFFER_SIZE];
    size_t total = 0;

    if (!user_buffer && size != 0) {
        return -EFAULT;
    }

    file_t* file = fd_get(fd);

    if (!file) {
        return -EBADF;
    }

    if (!file->ops || !file->ops->read) {
        file_put(file);
        return -EINVAL;
    }

    while (total < size) {
        size_t chunk = size - total;
        if (chunk > sizeof(buffer)) {
            chunk = sizeof(buffer);
        }

        ssize_t result = file->ops->read(file, buffer, chunk);

        if (result < 0) {
            if (total != 0) {
                break;
            }

            file_put(file);
            return result;
        }

        if (result == 0) {
            break;
        }

        if (copy_to_user((u8*)user_buffer + total, buffer, (size_t)result) < 0) {
            file_put(file);
            if (total != 0) {
                return (ssize_t)total;
            }

            return -EFAULT;
        }

        total += (size_t)result;
        
        if ((size_t)result < chunk) {
            break;
        }
    }

    file_put(file);

    return (ssize_t)total;
}

ssize_t sys_write(fd_t fd, const void* user_buffer, size_t size) {
    u8 buffer[SYSCALL_IO_BUFFER_SIZE];
    size_t total = 0;

    if (!user_buffer && size != 0) {
        return -EFAULT;
    }

    file_t* file = fd_get(fd);

    if (!file) {
        return -EBADF;
    }

    if (!file->ops || !file->ops->write) {
        file_put(file);
        return -EINVAL;
    }

    while (total < size) {
        size_t chunk = size - total;
        if (chunk > sizeof(buffer)) {
            chunk = sizeof(buffer);
        }

        if (copy_from_user(buffer, (const u8*)user_buffer + total, chunk) < 0) {
            file_put(file);
            if (total != 0) {
                return (ssize_t)total;
            }

            return -EFAULT;
        }

        ssize_t result = file->ops->write(file, buffer, chunk);

        if (result < 0) {
            if (total != 0) {
                break;
            }
            
            file_put(file);
            return result;
        }

        if (result == 0) {
            break;
        }

        total += (size_t)result;

        if ((size_t)result < chunk) {
            break;
        }
    }

    file_put(file);

    return (ssize_t)total;
}

int sys_close(fd_t fd) {
    return fd_close(fd);
}

__attribute__((noreturn)) void sys_exit(int code) {
    process_t* process = process_current();
    if (process) {
        process_exit(process, code);
    }

    task_exit();

    __builtin_unreachable();
}

u64 sys_spawn(const char* user_path) {
    if (!user_path) {
        return (u64)(i64)-EFAULT;
    }

char path[USER_PATH_MAX];

    int result = copy_user_path(path, user_path);
    if (result < 0) {
        return (u64)(i64)result;
    }

    process_t* parent = process_current();
    if (!parent) {
        return (u64)(i64)-ESRCH;
    }

    char resolved_path[USER_PATH_MAX];
    result = vfs_resolve_path(
        parent->cwd,
        path,
        resolved_path,
        sizeof(resolved_path)
    );
    if (result < 0) {
        return (u64)(i64)result;
    }

    process_t* process = process_create();
    if (!process) {
        return (u64)(i64)-ENOMEM;
    }

    process->parent = parent;
    strncpy(process->cwd, parent->cwd, sizeof(process->cwd) - 1);
    process->cwd[sizeof(process->cwd) - 1] = '\0';
    
    // inherit stdin, stdout, stderr, and any other open descriptors for the child
    result = fd_table_clone(&process->fd_table, &parent->fd_table);
    if (result < 0) {
        process_destroy(process);
        return (u64)(i64)result;
    }

    result = process_load_elf(process, resolved_path);
    if (result < 0) {
        process_destroy(process);
        return (u64)(i64)result;
    }

    result = process_start(process);
    if (result < 0) {
        process_destroy(process);
        return (u64)(i64)result;
    }

    return (u64)process->pid;
}

u64 sys_wait(u64 pid) {
    process_t* parent = process_current();
    if (!parent) {
        return (u64)(i64)-ESRCH;
    }

    process_t* child = process_find(pid);
    if (!child) {
        return (u64)(i64)-ESRCH;
    }

    if (child->parent != parent) {
        return (u64)(i64)-ECHILD;
    }

    // IMPORTANT NOTE: process_wait() doesn't destroy anything, it waits for the zombie, then process_reap() destroys the task / address space
    int status = process_wait(child);
    process_reap(child);

    return (u64)(i64)status;
}

ssize_t sys_window_create(const window_config_t* user_config) {
    if (!user_config) {
        return -EINVAL;
    }

    process_t* crnt = process_current();

    if (!crnt) {
        return -ESRCH;
    }

    if (crnt->window) {
        return -EFAULT;
    }

    window_config_t config;

    if (copy_from_user(&config, user_config, sizeof(config)) < 0) {
        return -EFAULT;
    }

    if (config.rect.width == 0 || config.rect.height == 0) {
        return -EINVAL;
    }

    char title[WINDOW_TITLE_MAX];
    memset(title, 0, WINDOW_TITLE_MAX);

    if (config.title) {
        u32 i = 0;
        b8 terminated = false;

        for (i = 0; i < WINDOW_TITLE_MAX - 1; ++i) {
            if (copy_from_user(&title[i], config.title + i, 1) < 0) {
                return -EFAULT;
            }

            if (title[i] == '\0') {
                terminated = true;
                break;
            }
        }

        if (!terminated) {
            return -ENAMETOOLONG;
        }
    }

    // TODO: may need a lock on this not sure...
    config.title = (const char*)title; // DO NOT pass user string to kernel
    crnt->window = window_server_create_window(&config);
    if (!crnt->window) {
        return -ENOMEM;
    }

    return 0;
}

ssize_t sys_window_destroy() {
    // TODO: may need a lock on this not sure...
    process_t* crnt = process_current();

    if (!crnt) {
        return -ESRCH;
    }

    if (!crnt->window) {
        return -EFAULT;
    }

    compositor_release_surface(crnt->window->surface->handle);
    window_server_destroy_window(crnt->window);

    return 0;
}

ssize_t sys_window_damage(const window_rect_t* rect) {
    process_t* crnt = process_current();

    if (!crnt) {
        return -ESRCH;
    }

    if (!crnt->window) {
        return -EFAULT;
    }

    window_rect_t krect;
    copy_from_user(&krect, rect, sizeof(window_rect_t));

    window_server_damage(crnt->window, krect.x, krect.y, krect.width, krect.height);

    return 0;
}

ssize_t sys_window_memcpy_frame(const void* user_buffer, size_t size) {
    process_t* crnt = process_current();

    if (!crnt) {
        return -ESRCH;
    }

    if (!crnt->window) {
        return -EFAULT;
    }

    if (!user_buffer || size != (crnt->window->surface->width * crnt->window->surface->height * sizeof(u32))) {
        return -EINVAL;
    }

    return copy_from_user(crnt->window->surface->pixels, user_buffer, size);
}

ssize_t sys_window_pop_event(window_event_t* evt) {
    process_t* crnt = process_current();

    if (!crnt) {
        return -ESRCH;
    }

    if (!crnt->window || !crnt->window->events) {
        return -EFAULT;
    }

    window_event_t kevt;
    if (ring_buffer_pop(crnt->window->events, &kevt)) {
        return copy_to_user(evt, &kevt, sizeof(window_event_t));
    }

    return -EFAULT; // idk what to return on failure
}

ssize_t sys_window_setup_terminal_io() {
    // TODO: remove
    // TODO: may need a lock on this not sure...
    process_t* crnt = process_current();

    if (!crnt) {
        return -ESRCH;
    }

    if (!crnt->window) {
        return -EFAULT;
    }
    
    terminal_t* terminal = console_terminal();

    terminal_init(terminal);
    terminal_attach_window(terminal, crnt->window);
    terminal_start_input_task(terminal); // todo: stop task
    return process_setup_stdio(crnt, terminal);
}

ssize_t sys_opendir(const char* user_path) {
    char path[USER_PATH_MAX];
    char resolved[USER_PATH_MAX];

    int result = copy_user_path(path, user_path);
    if (result < 0) {
        return result;
    }

    process_t* process = process_current();
    if (!process) {
        return -ESRCH;
    }

    result = vfs_resolve_path(process->cwd, path, resolved, USER_PATH_MAX);
    VFS_DIR* dir = vfs_opendir(resolved);
    if (!dir) {
        // TODO: future VFS error interface can distinguish ENOENT, ENOTDIR, and I/O errors instead of returning NULL
        return -ENOENT;
    }

    file_t* file = kmalloc(sizeof(file_t));
    if (!file) {
        vfs_closedir(dir);
        return -ENOMEM;
    }

    file_init(file, &directory_file_ops, dir);
    file->flags |= FILE_FLAG_DIRECTORY;

    fd_t fd = fd_alloc(file);

    // drop initial reference
    file_put(file);

    if (fd == FD_INVALID) {
        return -EMFILE;
    }

    return (ssize_t)fd;
}

ssize_t sys_readdir(fd_t fd, sys_dirent_t* user_entry) {
    if (!user_entry) {
        return -EFAULT;
    }

    file_t* file = fd_get(fd);
    if (!file) {
        return -EBADF;
    }

    if (!(file->flags & FILE_FLAG_DIRECTORY)) {
        file_put(file);
        return -ENOTDIR;
    }

    VFS_DIR* dir = (VFS_DIR*)file->private;
    if (!dir) {
        file_put(file);
        return -EBADF;
    }

    VFS_DIRENT vfs_entry;
    int result = vfs_readdir(dir, &vfs_entry);

    if (result == 0) {
        file_put(file);
        return 0;
    }

    if (result < 0) {
        file_put(file);
        return -EIO;
    }

    sys_dirent_t entry;
    memset(&entry, 0, sizeof(sys_dirent_t));
    memcpy(entry.name, vfs_entry.name, sizeof(entry.name));
    entry.name[SYS_DIRENT_NAME_MAX] = '\0';
    entry.size = vfs_entry.size;
    entry.type = (u32)vfs_entry.type;

    int copy_result = copy_to_user(user_entry, &entry, sizeof(sys_dirent_t));

    file_put(file);

    if (copy_result < 0) {
        return -EFAULT;
    }

    return 1;
}

// TODO: implement shrinking
// TODO: this version assumes only one thread can modify a process's heap at a time,
// this will need a dedicated per-process heap lock. however don't use spinlock for this idk wat to do
ssize_t sys_sbrk(ssize_t increment) {
    process_t* process = process_current();

    if (!process) {
        return -ESRCH;
    }

    // TODO:
    if (increment < 0) {
        return -EINVAL;
    }

    u64 old_break = process->heap_break;

    if (increment == 0) {
        return (ssize_t)old_break;
    }

    u64 new_break;

    if (__builtin_add_overflow(old_break, (u64)increment, &new_break)) {
        return -ENOMEM;
    }

    if (new_break > process->heap_limit) {
        return -ENOMEM;
    }

    u64 map_start;
    u64 map_end;

    if (__builtin_add_overflow(old_break, (u64)(PAGE_SIZE - 1), &map_start)) {
        return -ENOMEM;
    }

    map_start &= ~(PAGE_SIZE - 1);

    if (__builtin_add_overflow(new_break, (u64)(PAGE_SIZE - 1), &map_end)) {
        return -ENOMEM;
    }

    map_end &= ~(PAGE_SIZE - 1);

    u64 page_va;

    for (page_va = map_start; page_va < map_end; page_va += PAGE_SIZE) {

        if (vmm_virt_to_phys(process->space, page_va) != 0) {
            break;
        }

        paddr_t phys = pmm_alloc_page();
        if (!phys) {
            break;
        }

        memset((void*)phys_to_hhdm(phys), 0, PAGE_SIZE);

        int result = vmm_map(process->space, page_va, phys, PAGE_PRESENT | PAGE_USER | PAGE_WRITABLE);

        if (result < 0) {
            pmm_free_page(phys);
            break;
        }
    }

    if (page_va < map_end) {
        // roll back pages mapped by this request, heap_break remains unchanged
        for (u64 rollback = map_start; rollback < page_va; rollback += PAGE_SIZE) {
            paddr_t phys = vmm_virt_to_phys(process->space, rollback);

            if (phys) {
                vmm_unmap(process->space, rollback);
                pmm_free_page(phys & ~(PAGE_SIZE - 1));
            }
        }

        return -ENOMEM;
    }

    process->heap_break = new_break;

    return (ssize_t)old_break;
}

ssize_t sys_getcwd(char *user_buffer, size_t size) {
    if (!user_buffer) {
        return -EFAULT;
    }

    if (size == 0) {
        return -EINVAL;
    }

    process_t *process = process_current();
    if (!process) {
        return -ESRCH;
    }

    // ensure the kernel's cwd is terminated
    size_t len = strnlen(process->cwd, sizeof(process->cwd));

    if (len == sizeof(process->cwd)) {
        return -EINVAL;
    }

    size_t required = len + 1;

    if (size < required) {
        return -ERANGE;
    }

    if (copy_to_user(user_buffer, process->cwd, required) < 0) {
        return -EFAULT;
    }

    return (ssize_t)required;
}

ssize_t sys_chdir(const char *user_path) {
    char path[USER_PATH_MAX];
    char resolved[USER_PATH_MAX];

    int result = copy_user_path(path, user_path);
    if (result < 0) {
        return result;
    }

    process_t* process = process_current();
    if (!process) {
        return -ESRCH;
    }

    result = vfs_resolve_path(process->cwd, path, resolved, sizeof(resolved));

    if (result < 0) {
        return result;
    }

    VFS_DIR* dir = vfs_opendir(resolved);
    if (!dir) {
        return -ENOENT;
    }

    vfs_closedir(dir);

    size_t len = strlen(resolved);
    if (len >= sizeof(process->cwd)) {
        return -ENAMETOOLONG;
    }

    memcpy(process->cwd, resolved, len + 1);
    return 0;
}

u64 sys_get_time_ms() {
    return ktimer_get_system_time_in_milliseconds();
}

u64 syscall_dispatch(struct syscall_regs* r) {
    switch (r->rax) {
        case SYS_READ: {
            return (u64)sys_read((fd_t)r->rdi, (void*)r->rsi, (size_t)r->rdx);
        }
        case SYS_WRITE: {
            return (u64)sys_write((fd_t)r->rdi, (const void*)r->rsi, (size_t)r->rdx);
        }
        case SYS_CLOSE: {
            return (u64)sys_close((fd_t)r->rdi);
        }
        case SYS_EXIT: {
            sys_exit((int)r->rdi); // TODO: not sure if this returns something or no
        }
        case SYS_SPAWN: {
            return sys_spawn((const char*)r->rdi);
        }
        case SYS_WAIT: {
            return sys_wait(r->rdi);
        }
        case SYS_WINDOW_CREATE: {
            return (u64)sys_window_create((const window_config_t*)r->rdi);
        }
        case SYS_WINDOW_DESTROY: {
            return (u64)sys_window_destroy();
        }
        case SYS_WINDOW_DAMAGE: {
            return (u64)sys_window_damage((const window_rect_t*)r->rdi);
        }
        case SYS_WINDOW_MEMCPY_FRAME: {
            return (u64)sys_window_memcpy_frame((const void*)r->rdi, (size_t)r->rsi);
        }
        case SYS_WINDOW_POP_EVENT: {
            return (u64)sys_window_pop_event((window_event_t*)r->rdi);
        }
        case SYS_WINDOW_SETUP_TERMINAL_IO: {
            return (u64)sys_window_setup_terminal_io();
        }
        case SYS_OPENDIR: {
            return (u64)sys_opendir((const char*)r->rdi);
        }
        case SYS_READDIR: {
            return (u64)sys_readdir((fd_t)r->rdi, (sys_dirent_t*)r->rsi);
        }
        case SYS_SBRK: {
            return (u64)sys_sbrk((ssize_t)r->rdi);
        }
        case SYS_CHDIR: {
            return (u64)sys_chdir((const char*)r->rdi);
        }
        case SYS_GETCWD: {
            return (u64)sys_getcwd((char*)r->rdi, (size_t)r->rsi);
        }
        case SYS_GET_TIME_MS: {
            return sys_get_time_ms();
        }
        default: {
            return (u64)-ENOSYS;
        }
    }
}

void syscall_handler(struct syscall_regs* r) {
    r->rax = syscall_dispatch(r);
}